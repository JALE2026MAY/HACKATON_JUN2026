# Dashboard de Campaña Bancaria UCI - Scoring de Propensión
# Co-authored with CoCo
import streamlit as st
import os
import pandas as pd

st.set_page_config(page_title="Campaña Bancaria - Scoring", layout="wide")

conn = st.connection("snowflake", ttl=os.getenv("SNOWFLAKE_CONNECTION_TTL"))


@st.cache_data(ttl="5m")
def load_metrics():
    return conn.query("""
        SELECT F1_SCORE, PRECISION, RECALL, TP, FP, TN, FN, EVALUATION_TS
        FROM DB_UCI_BANK.SCORING.MODEL_EVALUATION_METRICS
    """)


@st.cache_data(ttl="5m")
def load_all_scores():
    return conn.query("""
        SELECT PROPENSITY_SCORE, JOB, EDUCATION, MARITAL, AGE, HOUSING, LOAN,
               CREDIT_DEFAULT, CONTACT, POUTCOME, WAS_PREVIOUSLY_CONTACTED,
               PREDICTED_TARGET, REAL_TARGET
        FROM DB_UCI_BANK.SCORING.BANK_ALL_SCORES
    """)


@st.cache_data(ttl="5m")
def load_top20():
    return conn.query("""
        SELECT PRIORITY_RANK, PROPENSITY_SCORE, JOB, EDUCATION, MARITAL,
               AGE, HOUSING, LOAN, CONTACT, POUTCOME,
               WAS_PREVIOUSLY_CONTACTED, PROBABILITY_SUBSCRIBED,
               PREDICTED_TARGET, REAL_TARGET
        FROM DB_UCI_BANK.SCORING.TOP_20_CALL_LIST
        ORDER BY PRIORITY_RANK
    """)


@st.cache_data(ttl="5m")
def load_dim_client():
    return conn.query("""
        SELECT AGE, JOB, MARITAL, EDUCATION, CREDIT_DEFAULT, HOUSING, LOAN, BALANCE
        FROM DB_UCI_BANK.DWH.DIM_CLIENT
    """)


@st.cache_data(ttl="5m")
def load_fact_calls_summary():
    return conn.query("""
        SELECT fc.TARGET, COUNT(*) as TOTAL_CALLS
        FROM DB_UCI_BANK.DWH.FACT_CALLS fc
        GROUP BY fc.TARGET
    """)


# --- Header ---
st.title("Campaña Bancaria UCI - Dashboard de Scoring")
st.caption("Propensión a suscribir depósito a plazo | Priorización de llamadas")

# --- Sidebar ---
with st.sidebar:
    st.header("Filtros")
    section = st.radio(
        "Sección",
        ["Resumen Ejecutivo", "Modelo de Scoring", "Lista Priorizada", "Análisis por Perfil"],
    )
    st.divider()
    st.button("Actualizar datos", on_click=lambda: (
        load_metrics.clear(),
        load_all_scores.clear(),
        load_top20.clear(),
        load_dim_client.clear(),
        load_fact_calls_summary.clear(),
    ))

# --- Load data ---
with st.spinner("Cargando datos..."):
    metrics_df = load_metrics()
    all_scores_df = load_all_scores()
    top20_df = load_top20()

# ===== SECCION 1: RESUMEN EJECUTIVO =====
if section == "Resumen Ejecutivo":
    st.header("Resumen Ejecutivo")

    f1 = metrics_df["F1_SCORE"].iloc[0]
    precision = metrics_df["PRECISION"].iloc[0]
    recall = metrics_df["RECALL"].iloc[0]
    tp = int(metrics_df["TP"].iloc[0])
    fp = int(metrics_df["FP"].iloc[0])
    tn = int(metrics_df["TN"].iloc[0])
    fn = int(metrics_df["FN"].iloc[0])

    total_clients = len(all_scores_df)
    top20_count = len(top20_df)
    avg_propensity_top20 = top20_df["PROPENSITY_SCORE"].mean()
    conversion_rate = all_scores_df["REAL_TARGET"].mean() * 100

    with st.container(horizontal=True):
        st.metric("F1 Score (KPI Estrella)", f"{f1:.4f}", border=True)
        st.metric("Precision", f"{precision:.4f}", border=True)
        st.metric("Recall", f"{recall:.4f}", border=True)
        st.metric("Total Clientes Evaluados", f"{total_clients:,}", border=True)

    with st.container(horizontal=True):
        st.metric("Top 20% Priorizados", f"{top20_count:,}", border=True)
        st.metric("Score Promedio Top 20%", f"{avg_propensity_top20:.1f}/100", border=True)
        st.metric("Tasa Conversión Real", f"{conversion_rate:.1f}%", border=True)

    st.divider()

    col1, col2 = st.columns(2)
    with col1:
        with st.container(border=True):
            st.subheader("Distribución de Propensity Score")
            hist_data = all_scores_df["PROPENSITY_SCORE"].dropna()
            bins = pd.cut(hist_data, bins=10, precision=0)
            dist_df = bins.value_counts().sort_index().reset_index()
            dist_df.columns = ["Rango", "Cantidad"]
            dist_df["Rango"] = dist_df["Rango"].astype(str)
            st.bar_chart(dist_df, x="Rango", y="Cantidad")

    with col2:
        with st.container(border=True):
            st.subheader("Resultado Real vs Predicción")
            comparison = all_scores_df.groupby(["REAL_TARGET", "PREDICTED_TARGET"]).size().reset_index(name="COUNT")
            comparison["REAL_TARGET"] = comparison["REAL_TARGET"].map({0: "No Suscribió", 1: "Suscribió"})
            comparison["PREDICTED_TARGET"] = comparison["PREDICTED_TARGET"].map({0: "Pred: No", 1: "Pred: Sí"})
            pivot = comparison.pivot(index="REAL_TARGET", columns="PREDICTED_TARGET", values="COUNT").fillna(0)
            st.dataframe(pivot, use_container_width=True)
            st.caption("Matriz de confusión simplificada")

    with st.container(border=True):
        st.subheader("Pipeline del Proyecto")
        st.markdown("""
        | Etapa | Herramienta | Estado |
        |-------|-------------|--------|
        | Ingesta UCI Bank → SingleStore | Talend | Completado |
        | Reglas DQ (balance, duration, pdays) | Talend / SQL | Completado |
        | ELT a Snowflake (fact_calls, dim_client, dim_campaign) | ELT SQL | Completado |
        | Modelo de Scoring (propensión 0-100) | Snowflake ML | Completado |
        | Priorización Top 20% | SQL | Completado |
        | Linaje + README | Catálogo | Completado |
        """)


# ===== SECCION 2: MODELO DE SCORING =====
elif section == "Modelo de Scoring":
    st.header("Modelo de Scoring - Evaluación")

    f1 = metrics_df["F1_SCORE"].iloc[0]
    precision = metrics_df["PRECISION"].iloc[0]
    recall = metrics_df["RECALL"].iloc[0]
    tp = int(metrics_df["TP"].iloc[0])
    fp = int(metrics_df["FP"].iloc[0])
    tn = int(metrics_df["TN"].iloc[0])
    fn = int(metrics_df["FN"].iloc[0])

    with st.container(horizontal=True):
        st.metric("F1 Score", f"{f1:.4f}", border=True)
        st.metric("Precision", f"{precision:.4f}", border=True)
        st.metric("Recall", f"{recall:.4f}", border=True)

    col1, col2 = st.columns(2)
    with col1:
        with st.container(border=True):
            st.subheader("Matriz de Confusión")
            confusion = pd.DataFrame(
                [[tp, fp], [fn, tn]],
                index=["Predicho: Sí", "Predicho: No"],
                columns=["Real: Sí", "Real: No"],
            )
            st.dataframe(confusion, use_container_width=True)
            total_test = tp + fp + tn + fn
            accuracy = (tp + tn) / total_test
            st.metric("Accuracy", f"{accuracy:.4f}")
            st.metric("Total muestra test (20%)", f"{total_test:,}")

    with col2:
        with st.container(border=True):
            st.subheader("Métricas Detalladas")
            metrics_detail = pd.DataFrame({
                "Métrica": ["True Positives", "False Positives", "True Negatives", "False Negatives",
                            "Precision", "Recall", "F1 Score", "Accuracy"],
                "Valor": [tp, fp, tn, fn,
                          f"{precision:.4f}", f"{recall:.4f}", f"{f1:.4f}", f"{accuracy:.4f}"],
                "Descripción": [
                    "Correctamente predijo suscripción",
                    "Predijo suscripción incorrectamente",
                    "Correctamente predijo no suscripción",
                    "No detectó suscripción real",
                    "De los que predijimos Sí, cuántos acertamos",
                    "De los que realmente suscribieron, cuántos detectamos",
                    "Media armónica de Precision y Recall",
                    "Proporción total de aciertos",
                ],
            })
            st.dataframe(metrics_detail, hide_index=True, use_container_width=True)

    st.divider()
    with st.container(border=True):
        st.subheader("Reglas de Calidad de Datos Aplicadas")
        st.markdown("""
        - **Balance**: sin valores negativos anómalos (validación en Talend)
        - **Duration**: excluida del modelo productivo (fuga de información)
        - **Pdays**: imputación correcta (-1 = no contactado previamente → variable binaria WAS_PREVIOUSLY_CONTACTED)
        """)


# ===== SECCION 3: LISTA PRIORIZADA =====
elif section == "Lista Priorizada":
    st.header("Top 20% - Lista Priorizada de Llamadas")
    st.caption("Clientes con mayor propensión a suscribir, ordenados por scoring")

    with st.container(horizontal=True):
        st.metric("Clientes en Top 20%", f"{len(top20_df):,}", border=True)
        st.metric("Score Mínimo Top 20%", f"{top20_df['PROPENSITY_SCORE'].min():.1f}", border=True)
        st.metric("Score Máximo Top 20%", f"{top20_df['PROPENSITY_SCORE'].max():.1f}", border=True)
        st.metric("Score Promedio Top 20%", f"{top20_df['PROPENSITY_SCORE'].mean():.1f}", border=True)

    with st.sidebar:
        st.subheader("Filtros Lista")
        job_filter = st.multiselect("Trabajo", options=sorted(top20_df["JOB"].unique()))
        education_filter = st.multiselect("Educación", options=sorted(top20_df["EDUCATION"].unique()))
        min_score = st.slider("Score mínimo", 0, 100, 50)

    filtered_df = top20_df.copy()
    if job_filter:
        filtered_df = filtered_df[filtered_df["JOB"].isin(job_filter)]
    if education_filter:
        filtered_df = filtered_df[filtered_df["EDUCATION"].isin(education_filter)]
    filtered_df = filtered_df[filtered_df["PROPENSITY_SCORE"] >= min_score]

    st.subheader(f"Mostrando {len(filtered_df):,} clientes")

    col1, col2 = st.columns(2)
    with col1:
        with st.container(border=True):
            st.subheader("Por Trabajo")
            job_dist = filtered_df.groupby("JOB")["PROPENSITY_SCORE"].agg(["mean", "count"]).reset_index()
            job_dist.columns = ["Trabajo", "Score Promedio", "Cantidad"]
            job_dist = job_dist.sort_values("Score Promedio", ascending=False)
            st.bar_chart(job_dist, x="Trabajo", y="Score Promedio")

    with col2:
        with st.container(border=True):
            st.subheader("Por Educación")
            edu_dist = filtered_df.groupby("EDUCATION")["PROPENSITY_SCORE"].agg(["mean", "count"]).reset_index()
            edu_dist.columns = ["Educación", "Score Promedio", "Cantidad"]
            edu_dist = edu_dist.sort_values("Score Promedio", ascending=False)
            st.bar_chart(edu_dist, x="Educación", y="Score Promedio")

    with st.container(border=True):
        st.subheader("Detalle de Clientes Priorizados")
        display_cols = ["PRIORITY_RANK", "PROPENSITY_SCORE", "JOB", "EDUCATION",
                        "AGE", "MARITAL", "CONTACT", "POUTCOME", "WAS_PREVIOUSLY_CONTACTED"]
        st.dataframe(
            filtered_df[display_cols].head(100),
            hide_index=True,
            use_container_width=True,
            column_config={
                "PRIORITY_RANK": st.column_config.NumberColumn("Rank", format="%d"),
                "PROPENSITY_SCORE": st.column_config.ProgressColumn(
                    "Score", min_value=0, max_value=100, format="%.1f"
                ),
            },
        )


# ===== SECCION 4: ANALISIS POR PERFIL =====
elif section == "Análisis por Perfil":
    st.header("Análisis de Propensión por Perfil de Cliente")

    with st.sidebar:
        st.subheader("Dimensión de análisis")
        dimension = st.selectbox(
            "Agrupar por",
            ["JOB", "EDUCATION", "MARITAL", "HOUSING", "LOAN", "CONTACT", "POUTCOME", "WAS_PREVIOUSLY_CONTACTED"],
        )

    grouped = all_scores_df.groupby(dimension).agg(
        Score_Promedio=("PROPENSITY_SCORE", "mean"),
        Score_Mediana=("PROPENSITY_SCORE", "median"),
        Cantidad=("PROPENSITY_SCORE", "count"),
        Tasa_Conversion_Real=("REAL_TARGET", "mean"),
    ).reset_index()
    grouped["Tasa_Conversion_Real"] = (grouped["Tasa_Conversion_Real"] * 100).round(2)
    grouped = grouped.sort_values("Score_Promedio", ascending=False)

    col1, col2 = st.columns(2)
    with col1:
        with st.container(border=True):
            st.subheader(f"Score Promedio por {dimension}")
            st.bar_chart(grouped, x=dimension, y="Score_Promedio")

    with col2:
        with st.container(border=True):
            st.subheader(f"Tasa de Conversión Real por {dimension}")
            st.bar_chart(grouped, x=dimension, y="Tasa_Conversion_Real")

    with st.container(border=True):
        st.subheader("Tabla Comparativa de Perfiles")
        st.dataframe(
            grouped,
            hide_index=True,
            use_container_width=True,
            column_config={
                "Score_Promedio": st.column_config.NumberColumn("Score Prom.", format="%.1f"),
                "Score_Mediana": st.column_config.NumberColumn("Score Med.", format="%.1f"),
                "Tasa_Conversion_Real": st.column_config.NumberColumn("Conv. Real %", format="%.2f%%"),
            },
        )

    st.divider()
    with st.container(border=True):
        st.subheader("Distribución por Edad")
        age_bins = pd.cut(all_scores_df["AGE"], bins=[0, 25, 35, 45, 55, 65, 100])
        age_score = all_scores_df.copy()
        age_score["RANGO_EDAD"] = age_bins.astype(str)
        age_grouped = age_score.groupby("RANGO_EDAD").agg(
            Score_Promedio=("PROPENSITY_SCORE", "mean"),
            Cantidad=("PROPENSITY_SCORE", "count"),
            Conversion=("REAL_TARGET", "mean"),
        ).reset_index()
        age_grouped["Conversion"] = (age_grouped["Conversion"] * 100).round(2)
        st.bar_chart(age_grouped, x="RANGO_EDAD", y=["Score_Promedio", "Conversion"])

# --- Footer ---
st.divider()
st.caption("Dashboard generado desde DB_UCI_BANK | Tablas: BANK_ALL_SCORES, TOP_20_CALL_LIST, MODEL_EVALUATION_METRICS")
